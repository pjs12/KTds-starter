SELECT empno, ename, sal
FROM emp
WHERE empno = 7521;

SELECT * FROM emp WHERE sal >= 2000;

SELECT empno, ename, job FROM emp WHERE deptno = 30;

SELECT * FROM emp WHERE sal BETWEEN 1000 AND 2000;
SELECT * FROM emp WHERE sal >= 1000 AND sal <= 2000;

SELECT * FROM emp WHERE hiredate BETWEEN '1981-01-01' AND '1981-12-31';

-- 30이 아닌 경우 --
SELECT * FROM emp WHERE deptno<>30;
-- 괄호 안의 값에 포함되는 경우--
SELECT * FROM emp WHERE deptno IN (10,20);

-- K로 시작하는 경우 --
SELECT * FROM emp WHERE ename LIKE 'K%';
-- K로 끝나는 경우 --
SELECT * FROM emp WHERE ename LIKE '%K';

SELECT * FROM student;
SELECT studno, NAME, tel FROM student WHERE NAME LIKE '김%';

-- 학번, 이름, 학년, 전공1, 전공2 (4학년이면서 전공1 이나 전공2가 201인 학생)
SELECT studno, NAME, grade, deptno1, deptno2 FROM student WHERE grade = 4 AND (deptno1 = 201 OR deptno2 = 201);

-- ORDER by
SELECT * FROM emp ORDER BY sal, empno;

-- emp 테이블에서 사번, 이름, job, sal, deptno 출력(deptno순, 같을 때는 sal순, 같을 때는 사번 내림차순)
SELECT empno, ename, job, sal, deptno FROM emp ORDER BY deptno, sal, empno DESC;

-- case절
SELECT empno, ename, 
case when deptno=10 then 'ACCOUNTINT'
	  when deptno=20 then 'RESEARCH'
	  when deptno=30 then 'SALES'
	  when deptno=40 then 'OPERATIONS'
	  ELSE 'ETC'
END AS dname
FROM emp;

-- 더하기 연산 시 하나가  null이면 결과가  null이 됨
-- null이면 다른 값으로 변경 : ifnull
SELECT empno, ename, sal+ifnull(comm, 0) AS pay FROM emp ORDER BY pay DESC;

-- 이름의 성만 가져오기
-- 해당 colomn 첫번째 문자부터 1개 가져오기 : SUBSTR
SELECT studno, SUBSTR(NAME, 1, 1) AS name FROM student;

-- 특정 char 위치 가져오기 : INSTR
SELECT studno, tel, SUBSTR(tel, 1, INSTR(tel, ')') - 1) AS '국번' FROM student;

-- 문자열 합치기 : CONCAT
SELECT CONCAT(NAME, '(', POSITION, ')') name FROM professor;
-- 문자 합칠 때 구분자 포함 : CONCAT_WS
SELECT CONCAT_WS('-', NAME, POSITION) name FROM professor;

-- ASCII 코드 값 : ASCII
SELECT ASCII('A');

-- 소수점 이하 자리 정하기 : format, 0으로하면 3자리마다 콤마 추가
SELECT empno, name, format(pay, 0) FROM emp2;

-- 문자열 모두 소문자로: LOWER, 대문자로: UPPER
SELECT LOWER(ename) FROM emp;
SELECT empno, ename, job FROM emp WHERE LOWER(job)='salesman';

-- 스페이스 바 삭제 : TRIM
SELECT TRIM('   abc   ');
SELECT LTRIM('   abc   ');
SELECT RTRIM('   abc   ');

-- 문자열 변경 : REPLACE
SELECT REPLACE('SQL tutorial', 'SQL', 'HTML');
SELECT REPLACE(NAME, SUBSTR(NAME, 2, 1), '*') AS NAME FROM student;

SELECT empno AS 사번, ename AS 이름 FROM emp ORDER BY 이름;

-- 문자열 왼쪽에서 해당 개수만큼 가져오기 : LEFT / RIGHT
SELECT LEFT(NAME, 2) FROM student;
SELECT RIGHT(NAME, 1) AS NAME FROM student;

-- 해당 숫자만큼 별표와 문자열로 채우기 : LPAD / RPAD
SELECT LPAD(ename, 10, ' ') FROM emp;
SELECT RPAD(ename, 10, ' ') FROM emp;

-- 나머지 함수 : MOD
SELECT MOD(10, 4);

-- 날짜 더하기 : ADDDATE
SELECT ADDDATE('2023-01-17', INTERVAL 10 DAY);
SELECT NOW(), ADDDATE(NOW(), INTERVAL 30 MINUTE);
SELECT NOW(), ADDDATE(NOW(), INTERVAL -2 HOUR);

SELECT ename, hiredate, ADDDATE(hiredate, INTERVAL 10 YEAR) 10년 FROM emp;

-- 날짜 빼기 : DATEDIFF
SELECT birthday, ROUND(DATEDIFF(NOW(), birthday)/365, 0) age FROM student;

SELECT hiredate, ROUND(DATEDIFF(NOW(), hiredate)/365, 0) 연차 FROM emp;

-- Date 관련
SELECT DAY(NOW());
SELECT MONTH(NOW());
SELECT YEAR(NOW());

SELECT * FROM emp WHERE YEAR(hiredate)=1981;

SELECT LAST_DAY(hiredate) FROM emp;

SELECT * FROM student WHERE MONTH(birthday) = MONTH(NOW());

SELECT EXTRACT(MONTH FROM NOW());

-- null인지 판단할때는 is null / is not null
SELECT * FROM emp WHERE comm is not NULL;

-- group function
-- column에 null이 있으면 제외하고 count함 주의
SELECT COUNT(*) FROM emp;

SELECT deptno, COUNT(*) FROM emp GROUP BY deptno;

-- group by 조건절은 having
SELECT COUNT(*), MIN(sal), MAX(sal), AVG(sal) FROM emp GROUP BY deptno HAVING deptno=10;

SELECT POSITION, AVG(pay) FROM professor GROUP BY POSITION HAVING POSITION='조교수';
SELECT POSITION, AVG(pay) FROM professor GROUP BY POSITION ORDER BY 2 DESC;

-- 다른 테이블에서 같은 column 값의 존재 여부 : EXISTS / NOT EXISTS
SELECT * FROM dept 
WHERE EXISTS(SELECT * FROM emp WHERE dept.deptno = emp.deptno);

SELECT * FROM professor p
WHERE not EXISTS(SELECT * FROM student s WHERE s.profno = p.profno);

-- 서브 쿼리에서 하나의 조건만 만족하면 true : ANY
-- deptno가 10인 사람들 중 sal이 가장 작은 사람보다만 크면 됨
SELECT empno, ename FROM emp WHERE sal > ANY (SELECT sal FROM emp WHERE deptno=10);

-- 서브 쿼리에서 모든 조건이 만족하면 true : ALL
-- deptno가 10인 사람들 중 sal이 가장 큰 사람보다 크면 됨
SELECT empno, ename FROM emp WHERE sal > ALL (SELECT sal FROM emp WHERE deptno=10);

SELECT * FROM emp2 WHERE pay >= ANY(SELECT pay FROM emp2 WHERE POSITION='과장');
SELECT * FROM emp2 WHERE pay >= ALL(SELECT pay FROM emp2 WHERE POSITION='과장');

-- ----------------------------------- join ----------------------------------------
-- INNER JOIN (JOIN)
-- column 명이 같을 경우 USING
SELECT e.empno, e.ename, d.dname FROM emp e JOIN dept d USING(deptno);
-- column 명이 다르거나 같을 경우 ON
SELECT e.empno, e.ename, d.dname FROM emp e JOIN dept d ON e.deptno = d.deptno;

-- 학생들의 학번, 이름, 학과명(제 1전공) 조회
SELECT s.studno, s.NAME, d.dname FROM student s JOIN department d ON s.deptno1 = d.deptno;
-- 학번, 이름, 담당교수 명 조회
SELECT s.studno, s.name, p.name AS 담당교수 FROM student s JOIN professor p ON s.profno = p.profno;

-- LEFT JOIN / RIGHT JOIN
-- JOIN 기준으로 왼쪽과 오른쪽 테이블의 data 조회
-- 학생과 담당교수를 조회하되 담당교수가 없는 학생들도 모두 조회
SELECT s.studno, s.name, p.name AS 담당교수 FROM student s LEFT JOIN professor p ON s.profno = p.profno;
-- 학생과 담당교수를 조회하되 담당 학생이 없는 교수들 모두 조회
SELECT s.studno, s.name, p.name AS 담당교수 FROM student s RIGHT JOIN professor p ON s.profno = p.profno;

-- OUTER JOIN ( LEFT JOIN 과 RIGHT JOIN 합집합)
SELECT s.studno, s.name, p.name AS 담당교수 FROM student s LEFT JOIN professor p ON s.profno = p.profno
UNION
SELECT s.studno, s.name, p.name AS 담당교수 FROM student s RIGHT JOIN professor p ON s.profno = p.profno;

-- CROSS JOIN
SELECT s.*, p.* FROM student s CROSS JOIN professor p ON s.profno = p.profno;

-- JOIN 2번하기
-- 학번, 이름, 학과명, 담당교수 명 조회
SELECT s.studno, s.name, d.dname, p.name FROM student s JOIN department d ON s.deptno1 = d.deptno LEFT JOIN professor p ON s.profno = p.profno;

-- 학번, 이름, 학년, 시험 점수, 학점 조회
SELECT s.studno, s.name, s.grade, e.total, h.grade AS 학점 
FROM student s LEFT JOIN exam_01 e ON s.studno=e.studno 
JOIN hakjum h ON e.total BETWEEN h.min_point AND h.max_point;

-- 고객번호, 이름, 소유포인트, gogak이 받을 수 있는 가장 좋은 gift 조회

SELECT go.gno, go.gname, go.point, gi.gname FROM gogak go JOIN gift gi ON go.point BETWEEN gi.g_start AND gi.g_end ORDER BY 3 DESC;

-- 노트북을 상품으로 받을 수 있는 고객의 고객번호, 이름, 포인트, 상품명 조회
SELECT go.gno, go.gname, go.point, gi.gname FROM gogak go JOIN gift gi ON go.point >= gi.g_start AND gi.gname='노트북' ORDER BY 3 DESC;

-- NEW YORK에서 근무하는 직원 중 커미션이 0이거나 null인 사원의 사번, 이름, 급여, 커미션 조회
SELECT e.EMPNO, e.ENAME, e.SAL, IFNULL(e.COMM, 0) as COMM, d.LOC 
FROM emp e JOIN dept d ON e.DEPTNO=d.DEPTNO
WHERE d.LOC='NEW YORK' AND IFNULL(e.COMM, 0) = 0;

-- 컴퓨터 공학과 교수가 담당하는 학생 중 4학년 학생의 학번, 이름, 학년 조회
SELECT s.studno, s.name, s.grade, p.name, d.dname 
FROM student s JOIN professor p ON s.profno=p.profno
JOIN department d ON p.deptno=d.deptno
WHERE s.grade=4 AND d.dname='컴퓨터공학과';

-- SELF JOIN
-- emp 테이블에서 사번, 이름, 담당관리자 이름 조회
SELECT e.empno, e.ename, m.ename FROM emp e
JOIN emp m ON e.MGR=m.empno;

-- SUB QUERY
-- '노트북'을 상품으로 받을 수 있는 고객의 고객번호, 이름, 포인트 조회
SELECT gno, gname, point FROM gogak 
WHERE POINT >= (SELECT g_start FROM gift WHERE gname='노트북') ORDER BY 3 DESC;

-- 서진수 학생과 제 1전공이 같은 학생의 학번, 이름, 학년 조회
SELECT studno, NAME, grade, deptno1 FROM student
WHERE deptno1 = (SELECT deptno1 FROM student WHERE NAME = '서진수');

-- 최슬기 교수보다 나중에 입사한 교수의 이름, 입사일, 학과명 조회
SELECT p.NAME, p.hiredate, d.dname FROM professor p
JOIN department d ON p.deptno=d.deptno
WHERE p.hiredate > (SELECT hiredate FROM professor WHERE NAME='최슬기');

-- 제 1전공이 201번인 학과의 평균 몸무게보다 몸무게가 많은 학생의 이름과 몸무게 조회
SELECT NAME, weight FROM student
WHERE weight > (SELECT AVG(weight) FROM student WHERE deptno1=201) ORDER BY 2;

-- 포항 본사에서 근무하는 사원의 사번, 이름, 부서번호 조회
SELECT empno, NAME, deptno FROM emp2 
WHERE deptno in (SELECT DCODE FROM dept2 WHERE AREA='포항본사');

-- 체중이 2학년 학생들의 체중에서 가장 적게 나가는 학생보다 많이 적게 나가는 학생의 이름, 학년, 체중 조회
SELECT NAME, grade, weight FROM student
WHERE weight < ALL(SELECT weight FROM student WHERE grade=2);

-- emp2, dept2 : 각 부서별 평균 연봉을 구하고 그 중에서 평균 연봉이 가장 적은 부서의 연봉보다
-- 적게 받는 직원들의 부서명, 직원이름, 연봉 조회
SELECT d.DNAME, e.NAME, e.PAY FROM emp2 e
JOIN dept2 d ON e.DEPTNO=d.DCODE
WHERE e.PAY < ALL(SELECT AVG(pay) FROM emp2 GROUP BY deptno) ORDER BY 3;

-- 각 학년별 최대 몸무게를 가진 학생들의 학년과 이름과 몸무게 조회
SELECT grade, NAME, weight FROM student
WHERE (grade, weight) IN (SELECT grade, MAX(weight) FROM student GROUP BY grade) ORDER BY 1;

-- professor, department : 각 학과별로 입사일이 가장 오래된 교수의 교수 번호, 이름, 학과명 조회
SELECT p.profno, p.NAME, p.hiredate, d.dname FROM professor p
JOIN department d ON p.deptno = d.deptno
WHERE (p.deptno, p.hiredate) IN (SELECT deptno, MIN(hiredate) FROM professor GROUP BY deptno);

-- 조건에 맞는 data가 여러 개일 경우
-- emp2 : 직급별로 해당 직급에서 최대 연봉을 받는 직원의 이름과 직급, 연봉 조회, 연봉 순으로
SELECT NAME, POSITION, pay FROM emp2
WHERE (POSITION, pay) IN (SELECT POSITION, MAX(pay) FROM emp2 GROUP BY POSITION) ORDER BY 3 DESC;

SELECT NAME, POSITION, max(pay) FROM emp2 GROUP BY POSITION;

-- 테이블 생성
kttestCREATE TABLE ACCOUNT(
-- column 나열
id INTEGER PRIMARY KEY,	-- int
NAME VARCHAR(100),		-- char(100)
balance INTEGER,
grade VARCHAR(10)
);

DROP TABLE ACCOUNT;

-- user table 생성
-- id int 기본키
-- name varchar(30)
-- email varchar(30)
-- joindate date
-- address varchar(50)
-- tel varchar(14)

CREATE TABLE USER(
id INTEGER NOT NULL,
NAME VARCHAR(30) NOT NULL,
email VARCHAR(30),
joindate DATE,
address VARCHAR(50),
tel VARCHAR(14),
PRIMARY KEY(id)
);

INSERT INTO user(id, NAME, email, joindate, address, tel)
VALUES (101, '홍길동', 'hong@kt.com', NOW(), '서울시 서초구', '010-1111-2222');

-- 모든 데이터를 column 순서대로 넣을 때는 생략 가능
INSERT INTO user
VALUES (102, '고길동', 'go@kt.com', NOW(), '서울시 강남구', '010-1111-1111');

INSERT INTO user(id, NAME)
VALUES (103, '하길동');

CREATE TABLE BOARD(
id INT AUTO_INCREMENT,
title VARCHAR(50),
content VARCHAR(2000),
writedate DATE,
writer INT,
PRIMARY KEY (id),
FOREIGN KEY (writer) REFERENCES user(id)
);

-- select로 테이블 생성
CREATE TABLE emp_temp
SELECT * FROM emp WHERE 1=2;
-- select로 데이터 삽입
INSERT INTO emp_temp
SELECT * FROM emp WHERE comm IS NOT NULL;

CREATE TABLE emp_d10
SELECT * FROM emp WHERE deptno=10;

CREATE TABLE emp_sub
SELECT empno, ename, hiredate FROM emp;

CREATE TABLE transfer_emp
SELECT * FROM emp WHERE 1=2;

-- column 추가
ALTER TABLE transfer_emp
ADD tdate DATE;

INSERT INTO transfer_emp
SELECT *,NOW() FROM emp WHERE deptno=30;

/* DELETE FROM emp
WHERE deptno=30; */

CREATE TABLE person(
id INT NOT NULL UNIQUE,
NAME VARCHAR(10)
);

-- 제약 조건 추가
CREATE TABLE person(
id INT NOT NULL,
NAME VARCHAR(10),
age INT,
city VARCHAR(30) DEFAULT '서울',
joindate DATE DEFAULT CURRENT_DATE(),
UNIQUE(id),
CHECK(age>=18)
);

-- 제약조건 이름 주기
CREATE TABLE person(
id INT NOT NULL,
NAME VARCHAR(10),
CONSTRAINT persons_id_u UNIQUE(id)
);

-- user table에 postcode 컬럼 추가
ALTER TABLE user
ADD postcode VARCHAR(10);

-- user table에서 postcode 컬럼 삭제
ALTER TABLE user
DROP COLUMN postcode;

-- user table에서 address 컬럼의 크기 및 타입 변경
ALTER TABLE user
MODIFY COLUMN address VARCHAR(200);

-- update
UPDATE account SET balance=balance+10000 WHERE id=1001;
UPDATE user SET email='ha@kt.com', address='경기도 용인시' WHERE NAME='하길동';

-- emp : 부서번호가 10인 사원들의 커미션을 급여의 10% 지급
UPDATE emp SET comm=sal*0.1 WHERE deptno=10;

-- delete
DELETE FROM user WHERE NAME='하길동';

-- writer는 foreign key이므로 user table의 id가 있는 값만 추가 가능
INSERT INTO board(title, content, writedate, writer)
VALUES ('제목', '내용', NOW(), 101);

INSERT INTO board
VALUES (NULL, '제목2', '내용2', CURDATE(), 102);

-- limit
SELECT * FROM board
LIMIT 2;		-- 첫번째부터 2개

SELECT * FROM board
LIMIT 1,2;	-- 1번째(0번째부터 시작)부터 2개

