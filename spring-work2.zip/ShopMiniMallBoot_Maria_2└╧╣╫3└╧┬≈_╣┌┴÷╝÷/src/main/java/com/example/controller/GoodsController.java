package com.example.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.dto.CartDTO;
import com.example.dto.GoodsDTO;
import com.example.dto.MemberDTO;
import com.example.dto.OrderDTO;
import com.example.service.CartService;
import com.example.service.GoodsService;

@Controller
public class GoodsController {

	@Autowired
	CartService cartService;

	@Autowired
	GoodsService goodsService;
	
	@RequestMapping("/cartOrderAllDone")//카트 번호를 이용한 다건 결제 처리
	public String cartOrderAllDone(HttpServletRequest request,
			HttpSession session, Model m) {
		MemberDTO mDTO = (MemberDTO)session.getAttribute("user");
		
		String orderName = request.getParameter("orderName");
		String phone = request.getParameter("phone");
		String payMethod = request.getParameter("payMethod");
		Calendar calendar = Calendar.getInstance();
		String nowdate = calendar.get(Calendar.YEAR) + "-" + calendar.get(Calendar.MONTH) + "-" + calendar.get(Calendar.DAY_OF_MONTH);
		
		List<String> checks = Arrays.asList(request.getParameterValues("num"));
		List<CartDTO> cartlist = cartService.orderAllConfirm(checks);
		
		List<OrderDTO> orderlist = new ArrayList<>();
		for(CartDTO cart : cartlist) {
			orderlist.add(new OrderDTO(0, mDTO.getUserid(), cart.getgCode(), cart.getgName(), cart.getgPrice(), cart.getgSize(),
									   cart.getgColor(), cart.getgAmount(), cart.getgImage(), orderName, mDTO.getPost(),
									   mDTO.getAddr1(), mDTO.getAddr2(), phone, payMethod, nowdate)); 
		}
		
		m.addAttribute("orderAllDone", orderlist);
		
		cartService.orderAllDone(orderlist, checks);
		
		return "orderAllDone";
	}

	@RequestMapping("/cartOrderAllConfirm")//카트 상품, 선택된 모든 카트번호를 이용한 다건 주문
	public String cartOrderAllConfirm(HttpServletRequest request, HttpSession session, Model m) {
		String[] checks = request.getParameterValues("check");
		List<String> checklist = Arrays.asList(checks);
		
		MemberDTO mDTO = (MemberDTO)session.getAttribute("user");
		if(mDTO != null) {
			List<CartDTO> list = cartService.orderAllConfirm(checklist);
			m.addAttribute("cartList", list);
		}
		
		return "orderAllConfirm";
	}

	@RequestMapping("/cartOrderDone")//카트 번호를 이용한 단건 결제 처리
	public String cartOrderDone(OrderDTO oDTO, HttpSession session,
			@RequestParam(required = false) String orderNum) {
		MemberDTO mDTO = (MemberDTO)session.getAttribute("user");
		oDTO.setUserid(mDTO.getUserid());
		
		cartService.orderDone(oDTO, orderNum);
		
		return "orderDone";
	}

	@RequestMapping("/cartOrderConfirm")//카트 상품 주문, 카트번호를 이용한 단건 주문
	public ModelAndView cartOrderConfirm(@RequestParam(value="num", required = false)  String num) {
		ModelAndView mav = new ModelAndView();
		
		try {
			CartDTO cDTO = cartService.cartbyNum(num);
			
			mav.addObject("cDTO", cDTO);
			mav.setViewName("orderConfirm");
		} catch(Exception e) {
			e.printStackTrace();
		}

		return mav;
	}
	
	@RequestMapping("/orderConfirm")//상품 상세에서 바로 주문, 카트 번호 미이용 단건 주문
	public ModelAndView orderConfirm(GoodsDTO gDTO,
									@RequestParam("gSize") String gSize,
									@RequestParam("gColor") String gColor,
									@RequestParam("gAmount") String gAmount){
		
		ModelAndView mav = new ModelAndView();
				
		mav.addObject("gSize", gSize);
		mav.addObject("gColor", gColor);
		mav.addObject("gAmount", gAmount);				
		mav.addObject("gDTO", gDTO);
		
		mav.setViewName("orderConfirm");
		
		return mav;
	}

	@RequestMapping("/CartDelAll")//카트 모든 상품 삭제
	public String CartDelAll(HttpServletRequest request) {	
		List<String> delList = Arrays.asList(request.getParameterValues("check"));
		
		cartService.cartAllDel(delList);
		
		return "redirect:/cartList";
	}

	@RequestMapping("/cartDelete")//카트 개별 상품 삭제
	@ResponseBody
	public void cartDelete(@RequestParam("num") int num) {
		cartService.cartDel(num);
	}

	@RequestMapping("/cartUpdate")//카트 개별 상품 수량 변경
	@ResponseBody
	public void cartUpdate(@RequestParam Map<String, Integer> map) {
		cartService.cartUpdate(map);
	}

	@RequestMapping("/cartList")
	public String cartList(HttpSession session, Model m) {
		String page = "cartList";

		MemberDTO mDTO = (MemberDTO)session.getAttribute("user");
		String userid = mDTO.getUserid();
		
		List<CartDTO> list = cartService.cartList(userid);
		m.addAttribute("cartList", list);
		
		return page;
	}

	@RequestMapping("/addCart")
	public String goodsCart(CartDTO cDTO, HttpSession session, Model m) {
		MemberDTO mDTO = (MemberDTO) session.getAttribute("user");
		String page = "redirect:/";
		
		if (mDTO != null) {
			cDTO.setUserid(mDTO.getUserid());
			cartService.cartAdd(cDTO);
			page = "redirect:/goodsRetrieve?gCode=" + cDTO.getgCode()+"&cart=Y";
		}
		return page;
	}

	@RequestMapping("/goodsList")
	public String goodsList(@RequestParam(value = "gCategory", required = false, defaultValue = "top")
							String gCategory,
							Model m) {
		/*
		 * 
		 * 
		 * 
		 */
		return "main";
	}

	@RequestMapping("/goodsRetrieve") 
	@ModelAttribute("item")  
	public GoodsDTO goodsRetrieve(@RequestParam("gCode") String gCode) {
		return goodsService.goodsRetrieve(gCode);
		
	}

}
