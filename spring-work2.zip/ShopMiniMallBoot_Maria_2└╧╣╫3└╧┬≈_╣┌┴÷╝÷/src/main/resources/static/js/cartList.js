$(document).ready(function(){

    	 //수정버튼
        $(".updateBtn").on("click",function(){
           	var num;
        	var gAmount;
        	var gPrice;
        	$.ajax({
        		url: 'cartUpdate',
        		type: 'get',
        		dataType:'text',
        		data: {
        			num: $("#check81").val(),
        			gAmount: Number($("input[name=cartAmount]").val()),
        		},
        		success: function(data, status, xhr) {
        			console.log("success: ", data);
        			alert("수량을 수정하였습니다.");
        		},
        		error:function(xhr,status,error){
        			console.log("error: ", data);
        			alert("수량 수정 에러");
        		}
			 	 
        	});//end ajax
        });
    	 
        //삭제버튼
        $(".delBtn").on("click",function(){
        	var num= $(this).attr("data-xxx");
        	var xxx = $(this);
        	$.ajax({
        		url:'cartDelete',
        		type:'get',
        		dataType:'text',
        		data:{
        			num:num
        		},
        		success:function(data,status,xhr){
        			alert("상품을 삭제하였습니다.");
        			location.href = "./cartList";
        		},
        		error:function(xhr,status,error){
        			alert("상품 삭제 에러");
        		}
        	});//end ajax
        });
 
        $("#mainBtn").click(function(){
			location.href="/shop/main";
		});
		$("#logoutBtn").click(function() {			
			location.href = "/shop/logout";	
			alert("로그아웃 되었습니다.");		
		});
		$("#myPageBtn").click(function() {
			location.href = "/shop/mypage";
		});
		$("#cartListBtn").click(function() {
			location.href = "/shop/cartList";
		});
		
		
        //전체선택
        $("#allCheck").on("click",function(){
        	if($("#allCheck").is(":checked")) {
        		$(".check").prop("checked", true);
        	} else {
        		$(".check").prop("checked", false);
        	}
        });
        
       
        $("#delAllCart").on("click",function(){
        	
        	$("form").attr("action", "CartDelAll");
        	$("form").submit();// trigger
        });
        
       
        $(".orderBtn").on("click",function(){
        	var num= $(this).attr("data-xxx");
        	location.href="cartOrderConfirm?num="+num;
        });
     
        $("#orderAllConfirm").on("click",function(){
        	$("form").attr("action", "cartOrderAllConfirm");
        	$("form").submit();// trigger
        });
   });