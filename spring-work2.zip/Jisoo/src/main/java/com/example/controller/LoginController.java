package com.example.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.dto.MemberDTO;
import com.example.service.MemberService;

@Controller
public class LoginController {
	
	@Autowired
	MemberService memberService;
	
	@Autowired
	HttpSession session;

	@RequestMapping("/login")
	public String login(@RequestParam("userid") String userid,
			@RequestParam("passwd") String passwd,
			Model model) {
		String page = "";
	
		Map<String, String> map = new HashMap<String, String>();
		map.put("userid", userid);
		map.put("passwd", passwd);
		
		MemberDTO member = memberService.login(map);
		
		if(member == null) {
			page = "memberResult";
			
			model.addAttribute("action", "로그인");
			model.addAttribute("message", "로그인 실패");
		} else {
			page = "redirect:main";
			
			session.setAttribute("user", member);
		}
		
		return page; 
	}
	
	@RequestMapping("/logout")
	public String logout() {
		
		MemberDTO member = (MemberDTO)session.getAttribute("user");
		
		if(member != null) {
			session.invalidate();
		}
				
		return "redirect:/";
	}
	
}





