package com.example.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.dto.MemberDTO;
import com.example.service.MemberService;

@Controller
public class MemberController {
	
	@Autowired
	MemberService memberService;
	
	@Autowired
	HttpSession session;
	
	@RequestMapping("/signUp")
	public String loginUI() {
		
		return "signUpForm";
	}
	
	@RequestMapping(value="/idCheck", produces = "text/plain;charset=UTF-8")
	@ResponseBody 
	public String idCheck(@RequestParam("id") String userid,
			@RequestParam("pw") String pw) {
		String mesg = "사용가능";

		if(memberService.idCheck(userid) != 0) {
			mesg = "사용불가";
		}
		
		return mesg;
	}
	
	
	@RequestMapping(value="/signUp", method = RequestMethod.POST)
	public String memberAdd(@ModelAttribute MemberDTO member, Model model){
		model.addAttribute("action", "회원가입");
		
		try {
			memberService.memberAdd(member);
			model.addAttribute("message", "회원가입 성공");
		} catch(Exception e) {
			model.addAttribute("message", "회원가입 실패");
		}
		
		return "memberResult";
	}

	@RequestMapping(value = "/updateMember", method = RequestMethod.POST)
	public String memberUpdate(@ModelAttribute MemberDTO member,
			Model model) {
		
		String page = "";
		
		model.addAttribute("action", "회원정보 수정");
		MemberDTO userInfo = (MemberDTO)session.getAttribute("user");
		
		try {
			memberService.memberUpdate(member);
			session.setAttribute("user", member);
			
			if(!userInfo.getPasswd().equals(member.getPasswd())) {
				model.addAttribute("changePasswd", true);
				session.removeAttribute("user");
				page = "shopMain";
			} else {
				session.setAttribute("user", member);
				model.addAttribute("message", "회원정보 수정 성공");
				page = "memberResult";
			}
		} catch(Exception e) {
			model.addAttribute("message", "회원정보 수정 실패");
			page = "memberResult";
		}
		
		return page;
	}
	
	@RequestMapping("/mypage")
	public String mypage() throws Exception {		
		
		MemberDTO member = (MemberDTO)session.getAttribute("user");
		
		if(member == null) {
			throw new Exception("로그인 후 이용하시기 바랍니다.");
		}
		
		return "mypage";  
	}		

}