package com.example.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.MemberDAO;
import com.example.dto.MemberDTO;


@Service
public class MemberServiceImpl implements MemberService{
	
	@Autowired
	MemberDAO memberDAO;

	public MemberDTO login(Map<String, String> map) {
		return memberDAO.login(map);
	}
	
	public int idCheck(String userid) {
		return memberDAO.idCheck(userid);
	}

	public int memberAdd(MemberDTO dto) {
		return memberDAO.memberAdd(dto);
	}
	
	public MemberDTO mypage(String userid) {
		return memberDAO.mypage(userid);
	}

	public int memberUpdate(MemberDTO dto) {
		return memberDAO.memberUpdate(dto);
	}
}



