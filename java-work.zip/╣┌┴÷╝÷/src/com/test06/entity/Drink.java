package com.test06.entity;

public class Drink {
	private int price;
	
	public Drink() {}
	public Drink(int price) {
		this.price = price;
	}
	
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
}
