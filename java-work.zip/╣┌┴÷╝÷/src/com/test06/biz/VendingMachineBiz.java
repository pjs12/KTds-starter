package com.test06.biz;

import com.test06.entity.Coffee;
import com.test06.entity.Coke;
import com.test06.entity.Drink;
import com.test06.entity.Juice;

public class VendingMachineBiz implements IVendingMachineBiz{
	private int balance = 1000;
	private Drink[] cartList = new Drink[3];
	private int count = 0;

	@Override
	public void cartDrink(Drink drink) {		
		if(balance < drink.getPrice()) {
			System.out.println("잔액이 부족하여 "+ drink.toString() + " 구매 불가능합니다.");
			return;
		}
		
		if(cartList.length <= count) {
			Drink[] newList = new Drink[cartList.length * 3];
			System.arraycopy(cartList, 0, newList, 0, cartList.length);
			cartList = newList;
		}
		
		cartList[count++] = drink;
		balance -= drink.getPrice();
		
		System.out.print(drink.toString() + "를 구입했습니다.");
		System.out.println("현재 잔액: " + balance +"원");
	}

	@Override
	public void printCart() {
		int cofcnt = 0, jucnt = 0, cokcnt = 0, totcnt = 0;
		
		for(int i = 0; i < count; i++) {
			totcnt += cartList[i].getPrice();
			
			if(cartList[i] instanceof Coffee)
				cofcnt++;
			else if(cartList[i] instanceof Juice)
				jucnt++;
			else if(cartList[i] instanceof Coke)
				cokcnt++;
		}
		
		System.out.println("===== 음료수 구입 목록 =====");
		if(cofcnt > 0)
			System.out.println("커피 : " + cofcnt + " 개");
		if(jucnt > 0)
			System.out.println("주스 : " + jucnt + " 개");
		if(cokcnt > 0)
			System.out.println("코크 : " + cokcnt + " 개");
		System.out.println("====================");
		
		System.out.println("사용 금액: " + totcnt + " 원");
		System.out.println("남은 금액: " + balance + " 원");
	}

	@Override
	public void printDrinkList(Drink[] drinkList) {
		System.out.println("======================");
		System.out.println("음료수명\t가격");
		System.out.println("======================");

		for(Drink drink : drinkList) {
			System.out.println(drink.toString() + "\t" + drink.getPrice() + "원");
		}
		
		System.out.println("----------------------");
		System.out.println("현재 잔액: " + balance + " 원");
	}

}
