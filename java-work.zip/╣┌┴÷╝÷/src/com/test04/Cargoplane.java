package com.test04;

public class Cargoplane extends Plane {
	public Cargoplane() {}
	public Cargoplane(String planeName, int fuel) {
		super(planeName, fuel);
	}
	
	@Override
	public void flight(int distance) {
		if(super.getFuelSize() >= distance * 5)
			super.setFuelSize(super.getFuelSize() - (distance * 5));
	}

}
