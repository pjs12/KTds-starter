package com.test04;

public class Airplane extends Plane{
	public Airplane() {}
	public Airplane(String planeName, int fuel) {
		super(planeName, fuel);
	}
	
	@Override
	public void flight(int distance) {
		if(super.getFuelSize() >= distance * 3)
			super.setFuelSize(super.getFuelSize() - (distance * 3));
	}
	
}
