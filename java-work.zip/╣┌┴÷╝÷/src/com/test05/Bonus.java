package com.test05;

public interface Bonus {
	void incentive(int pay);
}
