package com.test03;

import java.util.StringTokenizer;

public class TestMain03 {

	public static void main(String[] args) {
		String str = "1.22,4.12,5.93,8.71,9.34";
		
		// StringTokenizer 이용하여 List에 저장한다.
		StringTokenizer stk = new StringTokenizer(str, ",");
		double[] list = new double[stk.countTokens()];
		int count = 0;
		
		while(stk.hasMoreTokens()) {
			list[count++] = Double.parseDouble(stk.nextToken());
		}
		
		// List에 저장된 데이터의 합과 평균을 구한다.
		double total = 0.0, avg = 0.0;
		
		for(int i = 0; i < count; i++) {
			total += list[i];
		}
		avg = total / count;
		
		total = Math.round(total * 1000) / 1000.0;
		avg = Math.round(avg * 1000) / 1000.0;
		
		System.out.println("합 계: " + String.format("%.3f", total));
		System.out.println("평 균: " + String.format("%.3f", avg));		
	}

}
