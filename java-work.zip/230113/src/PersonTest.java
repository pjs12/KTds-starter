import pac.Person;

public class PersonTest {

	public static void main(String[] args) {
		Person p = new Person();
//		p.age = 10;
		p.setAge(10);
	}

}
