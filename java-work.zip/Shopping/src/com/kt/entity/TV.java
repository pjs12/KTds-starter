package com.kt.entity;

public class TV extends Product {
	static final int TV_PRICE = 2000;
	static final String TV_NAME = "TV";
	public TV() {
		super(TV_PRICE, TV_NAME);
	}
}
