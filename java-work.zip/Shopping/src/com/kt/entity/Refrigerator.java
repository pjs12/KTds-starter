package com.kt.entity;

public class Refrigerator extends Product {
	static final int REFRIGERATOR_PRICE = 3000;
	static final String REFRIGERATOR_NAME = "냉장고";
	public Refrigerator() {
		super(REFRIGERATOR_PRICE, REFRIGERATOR_NAME);
	}
}
