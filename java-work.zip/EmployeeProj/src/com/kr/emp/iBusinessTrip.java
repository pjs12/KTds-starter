package com.kr.emp;

public interface iBusinessTrip {
	void goBusinessTrip(int day);
}
