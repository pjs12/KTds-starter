
public class ForTest1 {

	public static void main(String[] args) {
//		int dan = 2;
		for(int i = 1; i <= 9; i++) {
			for(int dan = 2; dan <= 9; dan++) {
				System.out.print(dan + " x " + i + " = " + (dan * i) + "\t");
			}
			System.out.println();
		}
		
//		dan = 3;
//		int i = 1;
//		while(i <= 9) {
//			System.out.println(dan + " x " + i + " = " + (dan * i));
//			i++;
//		}
	}

}
