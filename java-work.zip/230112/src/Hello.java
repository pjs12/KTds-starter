
public class Hello {

	public static void main(String[] args) {
		String a = "i am hungry";
		
		for(int i = 0; i < a.length(); i++) {
			System.out.println(a.charAt(i));
		}

		System.out.println("Hello Java!!");
	}
}

