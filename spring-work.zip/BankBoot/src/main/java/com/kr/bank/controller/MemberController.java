package com.kr.bank.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.kr.bank.dto.Member;
import com.kr.bank.service.MemberService;

@Controller
public class MemberController {
	
	@Autowired
	MemberService memberService;
	
	@Autowired
	HttpSession session;
	
	@GetMapping("/join")
	public String join() {
		return "join";
	}
	
	@PostMapping("/join")
	public ModelAndView join(@ModelAttribute Member mem) {
		ModelAndView mav = new ModelAndView();
		try {
			memberService.makeMember(mem);
			
			mav.setViewName("login");
		} catch(Exception e) {
			e.printStackTrace();
			
			mav.addObject("err", "회원가입 오류");
			mav.setViewName("error");
		}
		
		return mav;
	}
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	@PostMapping("/login")
	public ModelAndView login(@RequestParam("id") String id, @RequestParam("password") String password) {
		ModelAndView mav =  new ModelAndView();
		try {
			Member mem = memberService.loginMember(id);
			
			if(mem != null && mem.getPassword().equals(password)) {
				session.setAttribute("id", id);
				
				mav.setViewName("makeAccount");
			}
			else {
				throw new Exception("로그인 오류");
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			mav.addObject("err", "로그인 오류");
			mav.setViewName("error");
		}
		
		return mav;
	}
	
	@GetMapping("/logout")
	public String logout() {
		session.removeAttribute("id");
		return "login";
	}
	
}
