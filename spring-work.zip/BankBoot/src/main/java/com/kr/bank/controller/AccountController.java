package com.kr.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.kr.bank.dto.Account;
import com.kr.bank.service.AccountService;

@Controller
public class AccountController {

	@Autowired
	AccountService accountService;
	
	@GetMapping("/")
	public String main() {
		return "bankmain";
	}
	
	@GetMapping("/allAccountInfo")
	public ModelAndView accountList() {
		ModelAndView mav = new ModelAndView();
		try {
			List<Account> accs = accountService.accountList();
			
			mav.addObject("accs", accs);
			mav.setViewName("allAccountInfo");
		} catch(Exception e) {
			e.printStackTrace();
			
			mav.addObject("err", "전체 계좌 조회 실패");
			mav.setViewName("error");
		}
		
		return mav;
	}
	
	@GetMapping("/accountInfo")
	public String accountInfo() {
		return "accountInfo";
	}
	
	@PostMapping("/accountInfo") 
	public ModelAndView accountInfo(@RequestParam("id") String id) {
		ModelAndView mav = new ModelAndView();
		try {
			Account acc = accountService.account(id);
			
			mav.addObject("acc", acc);
			mav.setViewName("accountInfo_success");
		} catch(Exception e) {
			e.printStackTrace();
			
			mav.addObject("err", "계좌 조회 실패");
			mav.setViewName("error");
		}
		
		return mav;
	}
	
	@GetMapping("/makeAccount")
	public String makeAccount() {
		return "makeAccount";
	}
	
	@PostMapping("/makeAccount")
	public ModelAndView makeAccount(@ModelAttribute Account acc){
		ModelAndView mav = new ModelAndView();
		try {
			accountService.makeAccount(acc);
			
			mav.addObject("id", acc.getId());
			mav.setViewName("makeAccount_success");
		} catch(Exception e) {
			e.printStackTrace();
			
			mav.addObject("err", "계좌 개설 실패");
			mav.setViewName("error");
		}
		
		return mav;
	}
	
	@GetMapping("/deposit")
	public String deposit() {
		return "deposit";
	}
	
	@PostMapping("/deposit")
	public ModelAndView deposit(@RequestParam("id") String id, @RequestParam("money") Integer money) {
		ModelAndView mav = new ModelAndView();
		try {
			Account acc = accountService.account(id);
			
			if(acc != null) {
				acc.deposit(money);
				accountService.updateAccount(acc);
			}
			
			mav.addObject("acc", acc);
			mav.setViewName("accountInfo_success");
		} catch(Exception e) {
			e.printStackTrace();
			
			mav.addObject("err", "입금 실패");
			mav.setViewName("error");
		}
		
		return mav;
	}
	
	@GetMapping("/withdraw")
	public String withdraw() {
		return "withdraw";
	}
	
	@PostMapping("/withdraw")
	public ModelAndView withdraw(@RequestParam("id") String id, @RequestParam("money") Integer money) {
		ModelAndView mav = new ModelAndView();
		try {
			Account acc = accountService.account(id);
			
			if(acc != null) {
				acc.withdraw(money);
				accountService.updateAccount(acc);
			}
			
			mav.addObject("acc", acc);
			mav.setViewName("accountInfo_success");
		} catch(Exception e) {
			e.printStackTrace();
			
			mav.addObject("err", "출금 실패");
			mav.setViewName("error");
		}
		
		return mav;
	}
	
	@ResponseBody
	@PostMapping("/doubleid")
	public ResponseEntity<Boolean> doubleid(@RequestParam("id") String id) {
		ResponseEntity<Boolean> res = null;
		try {
			res = new ResponseEntity<Boolean>(accountService.doubleId(id), HttpStatus.OK);
		} catch(Exception e) {
			e.printStackTrace();
			res = new ResponseEntity<Boolean>(HttpStatus.BAD_REQUEST);
		}
		
		return res;
	}
	
	@ResponseBody
	@PostMapping("accountInfo2")
	public ResponseEntity<Account> accountInfo2(@RequestParam("id") String id) {
		ResponseEntity<Account> res = null;
		
		try {
			Account acc = accountService.account(id);
			if(acc != null) {
				res = new ResponseEntity<Account>(acc, HttpStatus.OK);
			} else throw new Exception("계좌번호 오류");
		} catch(Exception e) {
			e.printStackTrace();
			return res = new ResponseEntity<Account>(new Account("noid", "noname", 0, null, null), HttpStatus.ACCEPTED);
		}
		
		return res;
	}
}
