package com.kr.bank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kr.bank.dao.MemberDAO;
import com.kr.bank.dto.Member;

@Service
public class MemberService implements IMemberService {
	
	@Autowired
	MemberDAO memberDAO;
	
	@Override
	public void makeMember(Member mem) throws Exception {
		memberDAO.insertMember(mem);
	}
	
	@Override
	public Member loginMember(String id) throws Exception {
		return memberDAO.selectMember(id);
	}
}
