package com.kr.bank.service;

import com.kr.bank.dto.Member;

public interface IMemberService {
	void makeMember(Member mem) throws Exception;
	Member loginMember(String id) throws Exception;
}
