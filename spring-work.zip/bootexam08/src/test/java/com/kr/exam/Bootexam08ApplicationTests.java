package com.kr.exam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bootexam08ApplicationTests {

	@Test
	void contextLoads() {
	}

}
