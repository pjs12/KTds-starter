package com.kr.exam.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.kr.exam.entity.Board;
import com.kr.exam.service.BoardService;

@Controller
public class BoardController {
	
	@Autowired
	BoardService boardService;
	
	@GetMapping("/home")
	public String main() {
		return "index";
	}
	
	@GetMapping("/list")
	public ModelAndView boardList() {
		ModelAndView mv = new ModelAndView();
		try {
			List<Board> boards = boardService.boardList();
			
			mv.addObject("boards", boards);
			mv.setViewName("list");
		} catch(Exception e) {
			e.printStackTrace();
			
			mv.setViewName("error");
		}
		return mv;
	}
	
	@GetMapping("/write")
	public String writeForm() {
		return "writeForm";
	}
	
	@PostMapping("/write")
	public ModelAndView boardwrite(@ModelAttribute Board board,
			HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();
		
		try {
			boardService.boardWrite(board);
			
			mv.setViewName("redirect:/list");
		} catch(Exception e) {
			e.printStackTrace();
			
			mv.setViewName("error");
		}
		
		return mv;
	}
	
	@GetMapping("/delete/{no}")
	public ModelAndView deleteBoard(@PathVariable Integer no) {
		ModelAndView mv = new ModelAndView();
		try {
			boardService.deleteBoard(no);
			
			mv.setViewName("redirect:/list");
		} catch(Exception e) {
			e.printStackTrace();
			
			mv.setViewName("error");
		}
		
		return mv;
	}
	
	@GetMapping("/retrieve")
	public ModelAndView boardDetail(@RequestParam("no") Integer no) {
		ModelAndView mv = new ModelAndView();
		try {
			Board board = boardService.boardDetail(no);
			
			mv.addObject("article", board);
			mv.setViewName("retrieve");
		} catch(Exception e) {
			e.printStackTrace();
			
			mv.setViewName("error");
		}
		return mv;
	}
	
	@PostMapping("/update")
	public ModelAndView boardModify(@RequestParam("title") String title,
			@RequestParam("content") String content, @RequestParam("no") Integer no) {
		ModelAndView mv = new ModelAndView();
		try {
			boardService.boardModify(title, content, no);
			
			mv.setViewName("redirect:/list");
		}catch(Exception e) {
			e.printStackTrace();
			
			mv.setViewName("error");
		}
		return mv;
	}
	
	@GetMapping("/search")
	public ModelAndView search(@RequestParam("searchName") String type,
			@RequestParam("searchValue") String word) {
		ModelAndView mv = new ModelAndView();
		try {
			List<Board> boards = boardService.searchBoard(type, word);
			
			mv.addObject("boards", boards);
			mv.setViewName("list");
		} catch(Exception e) {
			e.printStackTrace();
			
			mv.setViewName("error");
		}
		return mv;
	}
}
