package com.kr.exam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bootexam08Application {

	public static void main(String[] args) {
		SpringApplication.run(Bootexam08Application.class, args);
	}

}
