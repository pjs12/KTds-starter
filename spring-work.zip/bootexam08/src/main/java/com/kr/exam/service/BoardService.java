package com.kr.exam.service;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kr.exam.entity.Board;
import com.kr.exam.entity.Member;
import com.kr.exam.repository.BoardRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class BoardService {
	
	@Autowired
	BoardRepository boardRepository;

	@Autowired
	HttpSession session;
	
	public List<Board> boardList() {
		return boardRepository.findAll();
	}
	
	public void boardWrite(Board board) throws Exception {
		Member member = (Member)session.getAttribute("member");
		board.setUserid(member.getUserid());
		
		boardRepository.save(board);
	}

	public void deleteBoard(Integer no) throws Exception {
		boardRepository.deleteById(no);
	}

	public Board boardDetail(Integer no) throws Exception {
		Optional<Board> oboard = boardRepository.findById(no);
		if(oboard.isEmpty())
			throw new Exception("글번호 오류");
		
		boardRepository.readCntInc(no);
		Board board = oboard.get();
		return board;
	}

	public void boardModify(String title, String content, Integer no) {
		boardRepository.updateBoard(title, content, no);
	}
	
	public List<Board> searchBoard(String type, String word) throws Exception {
		if(word.equals("")) {
			return boardList();
		} else if(type.equals("username")) {
			return boardRepository.findByUsernameContains(word);
		} else if(type.equals("title")) {
			return boardRepository.findByTitleContains(word);
		} else return boardList();
	}
}
