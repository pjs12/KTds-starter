package com.kt.board.service;

import java.io.File;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.kt.board.dao.BoardDAO;
import com.kt.board.dto.Board;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	BoardDAO boardDAO;
	
	@Override
	public List<Board> getBoardList() throws Exception {
		return boardDAO.selectBoardList();
	}
	
	@Override
	public void boardWrite(Board board, MultipartFile mfile) throws Exception {
		if(mfile !=null && !mfile.isEmpty()) {
			String path = "D:\\pjs\\spring-work\\Board\\upload\\";
			File file = new File(path + mfile.getOriginalFilename());
			
			// path에 파일 이동 (저장)
			mfile.transferTo(file);
			board.setFilename(mfile.getOriginalFilename());
		}
		boardDAO.insertBoard(board);
	}

	@Override
	public Board getBoard(Integer num) throws Exception {
		return boardDAO.selectBoard(num);
	}
}
