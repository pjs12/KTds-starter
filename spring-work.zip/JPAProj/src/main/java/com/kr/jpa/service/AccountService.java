package com.kr.jpa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kr.jpa.entity.Account;
import com.kr.jpa.repository.AccountRepository;

@Service
public class AccountService {
	
	@Autowired
	AccountRepository accountRepository;
	
	public Account accountInfo(String id) {
		Optional<Account> oacc = accountRepository.findById(id);
		Account acc = null;
		
		if(oacc.isPresent()) {
			acc = oacc.get();
		}
		
		return acc;
	}
	
	public void makeAccount(Account acc) throws Exception {
		// save method는 없으면 생성, 있으면 업데이트
		accountRepository.save(acc);
	}

	public Account deposit(String id, Integer money) throws Exception {
		Optional<Account> oacc = accountRepository.findById(id);
		if(oacc.isEmpty())
			throw new Exception("계좌번호 오류");
		
		Account acc = oacc.get();
		acc.deposit(money);
		accountRepository.save(acc);
		
		return acc;
	}

	public Account withdraw(String id, Integer money) throws Exception {
		Optional<Account> oacc = accountRepository.findById(id);
		if(oacc.isEmpty())
			throw new Exception("계좌번호 오류");
		
		Account acc = oacc.get();
		acc.withdraw(money);
		accountRepository.save(acc);
		
		return acc;
	}

	public List<Account> allAccountInfo() throws Exception {
		return accountRepository.findAll();
	}
}
