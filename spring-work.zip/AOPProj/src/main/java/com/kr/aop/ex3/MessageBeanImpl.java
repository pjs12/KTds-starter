package com.kr.aop.ex3;

import org.springframework.beans.factory.annotation.Required;

// 핵심 관심 사항
public class MessageBeanImpl implements MessageBean {
	private String name;
	
	// setter 메서드에 Required Annotation을 넣어주면 bean 객체에 property를 설정하도록 강제 규정
	@Required
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public void sayHello() {
		try {
			Thread.sleep(5000);
		} catch(InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Hello, " + name + "!");
	}

}
