package com.kr.aop.ex3;

public interface MessageBean {
	void sayHello();
}
