package com.kr.aop.ex1;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.util.StopWatch;

// Spring Framework가 제공하는 AOP
public class LoggingAdvice implements MethodInterceptor {

	@Override
	// invocation: 핵심 로직의 joinpoint
	public Object invoke(MethodInvocation invocation) throws Throwable {
		String methodName = invocation.getMethod().getName();
		StopWatch sw = new StopWatch();
		sw.start(methodName);
		
		System.out.println("[LOG] METHOD : " + methodName + " is calling.");
		
		Object rntObj = invocation.proceed();
		sw.stop();
		System.out.println("[LOG] METHOD : " + methodName + " was called.");
		System.out.println("[LOG] 처리시간 : " + sw.getTotalTimeMillis()/1000 + "초");
		
		return rntObj;
	}

}
