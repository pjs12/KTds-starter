package com.kr.board.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.DynamicInsert;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@DynamicInsert
@Entity
public class Member {
	@Id
	private String id;
	
	@Column
	private String password;
	
	@Column
	private String name;
	
	@Column
	private String sex;
	
	@Column
	private int age;
	
	@Column
	private String email;
}
