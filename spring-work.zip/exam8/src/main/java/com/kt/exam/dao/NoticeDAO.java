package com.kt.exam.dao;

import java.util.HashMap;
import java.util.List;

import com.kt.exam.dto.Notice;

public interface NoticeDAO {
	List<Notice> selectNoticeList() throws Exception;
	void insertNotice(Notice notice) throws Exception;
	Notice selectNotice(Integer no) throws Exception;
	void updateReadCnt(Integer no) throws Exception;
	void updateNotice(HashMap<String, Object> map) throws Exception;
	void deleteNotice(Integer no) throws Exception;
	List<Notice> selectByAuthor(String author) throws Exception;
	List<Notice> selectByTitle(String title) throws Exception;
}
