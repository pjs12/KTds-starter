package com.kt.exam.controller;

import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.kt.exam.dto.Notice;
import com.kt.exam.service.NoticeService;

@Controller
public class NoticeController {
	
	@Autowired
	NoticeService noticeService;
	
	@GetMapping("/list")
	public ModelAndView noticeList() {
		ModelAndView mav = new ModelAndView();
		try {
			List<Notice> notices = noticeService.getNoticeList();
			
			if(notices.size() > 0) {
				mav.addObject("notices", notices);
			}
			mav.setViewName("list");
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return mav;
	}
	
	@GetMapping("/image/{filename:.+}")
	public void imageView(@PathVariable String filename,
			HttpServletResponse response) {
		try {
			String path = "D:\\pjs\\spring-work\\exam8\\image\\";
			FileInputStream fis = new FileInputStream(path + filename);
			
			OutputStream out = response.getOutputStream();
			FileCopyUtils.copy(fis, out);
			
			fis.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@GetMapping("/write")
	public String writeNotice() {
		return "writeForm";
	}
	
	@PostMapping("/write")
	public ModelAndView writeNotice(@ModelAttribute Notice notice) {
		ModelAndView mav = new ModelAndView();
		try {
			if(notice.getTitle().isEmpty()) {
				notice.setTitle("!");
			}
			if(notice.getAuthor().isEmpty()) {
				notice.setAuthor("?");
			}
			noticeService.writeNotice(notice);
			
			mav.setViewName("redirect:/list");
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return mav;
	}
	
	@GetMapping("/retrieve")
	public ModelAndView retrieve(@RequestParam("no") Integer no) {
		ModelAndView mav = new ModelAndView();
		try {
			Notice notice = noticeService.getNotice(no);
			
			mav.addObject("notice", notice);
			mav.setViewName("retrieve");
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return mav;
	}
	
	@PostMapping("/update")
	public ModelAndView modifyNotice(@RequestParam("no") Integer no,
			@RequestParam("title") String title,
			@RequestParam("author") String author,
			@RequestParam("content") String content) {
		ModelAndView mav = new ModelAndView();
		try {
			noticeService.modifyNotice(no, title, author, content);
			
			mav.setViewName("redirect:/list");
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return mav;
	}
	
	@GetMapping("/delete")
	public ModelAndView removeNotice(@RequestParam("no") Integer no) {
		ModelAndView mav = new ModelAndView();
		try {
			noticeService.removeNotice(no);
			
			mav.setViewName("redirect:/list");
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return mav;
	}
	
	@GetMapping("/search")
	public ModelAndView searchBoard(@RequestParam("searchName") String name,
			@RequestParam("searchValue") String value) {
		ModelAndView mav = new ModelAndView();
		try {
			List<Notice> notices = noticeService.boardSearch(name, value);
			
			mav.addObject("notices", notices);
			mav.setViewName("list");
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return mav;
	}
}
