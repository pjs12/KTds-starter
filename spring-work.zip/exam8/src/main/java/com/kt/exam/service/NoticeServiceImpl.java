package com.kt.exam.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kt.exam.dao.NoticeDAO;
import com.kt.exam.dto.Notice;

@Service
public class NoticeServiceImpl implements NoticeService {
	
	@Autowired
	NoticeDAO noticeDAO;
	
	@Override
	public List<Notice> getNoticeList() throws Exception {
		return noticeDAO.selectNoticeList();
	}
	
	@Override
	public void writeNotice(Notice notice) throws Exception {
		noticeDAO.insertNotice(notice);
	}
	
	@Override
	public Notice getNotice(Integer no) throws Exception {
		noticeDAO.updateReadCnt(no);
		return noticeDAO.selectNotice(no);
	}
	
	@Override
	public void modifyNotice(Integer no, String title, String author, String content) throws Exception {
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("no", no);
		params.put("title", title);
		params.put("author", author);
		params.put("content", content);
		
		noticeDAO.updateNotice(params);
	}
	
	@Override
	public void removeNotice(Integer no) throws Exception {
		noticeDAO.deleteNotice(no);
	}
	
	@Override
	public List<Notice> boardSearch(String name, String value) throws Exception {
		List<Notice> notices = null;
		if(name.equals("author")) {
			notices = noticeDAO.selectByAuthor(value);
		} else if(name.equals("title")) {
			notices = noticeDAO.selectByTitle(value);
		}
		
		if(value == null || value.equals("")) {
			notices = noticeDAO.selectNoticeList();
		}
		
		return notices;
	}
}
