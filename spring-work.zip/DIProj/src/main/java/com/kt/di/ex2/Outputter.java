package com.kt.di.ex2;

import java.io.IOException;

public interface Outputter {
	public void output(String mesaage) throws IOException;
}
