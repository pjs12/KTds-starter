$(function(){
	$('input[type="radio"]').change(function() {
	    let type = $('input[type="radio"]:checked').val();
	    
	    if(type=='special') {
	        $('select').attr('disabled',false);
	    } else {
	        $('select').attr('disabled',true);
	    }
	});
});