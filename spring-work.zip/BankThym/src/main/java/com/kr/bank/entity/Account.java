package com.kr.bank.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity			// JPA Entity
public class Account {
	@Id			// Primary Key
	private String id;
	@Column		// Column
	private String name;
	@Column
	private Integer balance;
	@Column
	private String type;
	@Column
	private String grade;
	
	public void deposit(int money) {
		if(money > 0) {
			balance += money;
		}
	}
	
	public void withdraw(int money) {
		if(balance >= money) {
			balance -= money;
		}
	}
}
