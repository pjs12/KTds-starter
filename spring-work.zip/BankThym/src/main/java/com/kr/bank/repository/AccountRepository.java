/**
 * 
 */
package com.kr.bank.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kr.bank.entity.Account;

/**
 * @author User
 *
 */
public interface AccountRepository extends JpaRepository<Account, String> {
	public List<Account> findByType(String type);
	public List<Account> findByTypeAndGrade(String type, String grade);
	
	public List<Account> findByNameContains(String name);
	public List<Account> findByNameLike(String name);
}
