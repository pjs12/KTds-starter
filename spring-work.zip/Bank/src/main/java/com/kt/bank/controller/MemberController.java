package com.kt.bank.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.kt.bank.dao.MemberDAO;
import com.kt.bank.dto.Account;
import com.kt.bank.dto.Member;

@Controller
public class MemberController {
	
	@Autowired
	private MemberDAO memberDAO;
	
	// 로그인되어있는 상황 세션에 저장
	@Autowired
	HttpSession session;
	
	@RequestMapping(value="/join", method=RequestMethod.GET)
	public String join() {
		return "join";
	}
	
	@RequestMapping(value="/join", method=RequestMethod.POST)
	public String join(@ModelAttribute Member mem, Model model) {
		try {
			memberDAO.insertMember(mem);
			return "login";
		} catch(Exception e) {
			e.printStackTrace();
			model.addAttribute("err", "회원가입 실패");
			return "error";
		}
	}
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String login() {
		return "login";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String login(@RequestParam("id") String id, @RequestParam("password") String password, Model model) {
		try {
			Member mem = memberDAO.selectMember(id);
			if(mem != null && mem.getPassword().equals(password)) {
				session.setAttribute("id", id);
				return "makeAccount";
			}
			else {
				throw new Exception("로그인 실패");
			}
		} catch(Exception e) {
			e.printStackTrace();
			model.addAttribute("err", "로그인 실패");
			return "error";
		}
	}
	
	@RequestMapping(value="/logout", method=RequestMethod.GET)
	public String logout() {
		session.removeAttribute("id");
		return "login";
	}
}
