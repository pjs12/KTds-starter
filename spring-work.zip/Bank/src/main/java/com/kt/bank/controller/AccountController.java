package com.kt.bank.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.kt.bank.dao.AccountDAO;
import com.kt.bank.dto.Account;

@Controller
public class AccountController {
	
	@Autowired
	private AccountDAO accountDAO;
	
	// 여러가지 url을 mapping 할 수 있음
	
	@RequestMapping(value="/", method=RequestMethod.GET)
	public String main() {
		// view 파일 명을 return 해주면 viewResolver가 파일을 찾아줌
		return "bankmain";
	}
	
	@RequestMapping(value="/makeAccount", method=RequestMethod.GET)
	public String makeAccount() {
		return "makeAccount";
	}
	
	@RequestMapping(value="/makeAccount", method=RequestMethod.POST)
	/* 
	 * @ModelAttribute
	 * 클래스의 멤버 변수명과 jsp 파일의 입력 태그 name을 맞춰주면 클래스 객체로 받아올 수 있음
	 * ex: Account 클래스의 변수명과 makeAccount.jsp의 input 태그 name attribute를 맞춰주면
	 * Account 클래스 객체로 받아옴
	 */
	public String makeAccount(@ModelAttribute Account acc, Model model) {
		try {
			accountDAO.insertAccount(acc);
			model.addAttribute("id", acc.getId());
			return "makeAccount_success";
		} catch(Exception e) {
			e.printStackTrace();
			model.addAttribute("err", "계좌 개설 실패");
			return "error";
		}
	}

	@RequestMapping(value="/deposit", method=RequestMethod.GET)
	public String deposit() {
		return "deposit";
	}

	@RequestMapping(value="/deposit", method=RequestMethod.POST)
	public ModelAndView deposit(@RequestParam("id") String id, @RequestParam("money") Integer money) {
		ModelAndView mav = new ModelAndView();
		try {
			Account acc = accountDAO.selectAccount(id);
			acc.deposit(money);
			// DB 데이터 변경
			accountDAO.updateBalance(acc);
			
			// Model 추가
			mav.addObject("acc", acc);
			// View 추가
			mav.setViewName("accountInfo_success");
		} catch(Exception e) {
			e.printStackTrace();
			
			mav.addObject("err", "입금 실패");
			mav.setViewName("error");
		}
		
		return mav;
	}
	
	@RequestMapping(value="/withdraw", method=RequestMethod.GET)
	public String withdraw() {
		return "withdraw";
	}
	
	@RequestMapping(value="/withdraw", method=RequestMethod.POST)
	public ModelAndView withdraw(@RequestParam("id") String id, @RequestParam("money") Integer money) {
		ModelAndView mav = new ModelAndView();
		try {
			Account acc = accountDAO.selectAccount(id);
			if(acc == null)
				throw new Exception("계좌번호 오류");
			acc.withdraw(money);
			
			HashMap<String, Object> param = new HashMap<>();
			param.put("id", id);
			param.put("balance", acc.getBalance());
			accountDAO.updateBalance2(param);
			
			mav.addObject("acc", acc);
			mav.setViewName("accountInfo_success");
		} catch(Exception e) {
			e.printStackTrace();
			mav.addObject("err", "출금 실패");
			mav.setViewName("error");
		}
		
		return mav;
	}
	
	@RequestMapping(value="/accountInfo", method=RequestMethod.GET)
	public String accountInfo() {
		return "accountInfo2";
	}
	
	@RequestMapping(value="/accountInfo", method=RequestMethod.POST)
	public String accountInfo(@RequestParam("id") String id, Model model) {
		try {
			Account acc = accountDAO.selectAccount(id);
			model.addAttribute("acc", acc);
			return "accountInfo_success";
		} catch(Exception e) {
			e.printStackTrace();
			model.addAttribute("err", "계좌 조회 실패");
			return "error";
		}
	}
	
	@RequestMapping(value="/allAccountInfo", method=RequestMethod.GET)
	public ModelAndView allAccountInfo() {
		ModelAndView mav = new ModelAndView();
		try {
			List<Account> accs = accountDAO.selectAllAccount();
			
			mav.addObject("accs", accs);
			mav.setViewName("allAccountInfo");
		} catch(Exception e) {
			e.printStackTrace();
			
			mav.addObject("err", "전체 계좌 조회 실패");
			mav.setViewName("error");
		}
		
		return mav;
	}
	
	// 데이터만 리턴
	@ResponseBody
	@PostMapping("/doubleid")
	public ResponseEntity<String> doubleId(@RequestParam("id") String id) {
		ResponseEntity<String> res = null;
		
		try {
			Account acc = accountDAO.selectAccount(id);
			if(acc != null) {
				return new ResponseEntity<String>("true", HttpStatus.OK);
			}
			else {
				return new ResponseEntity<String>("false", HttpStatus.OK);
			}
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
		}
		
	}
	
	@ResponseBody
	@PostMapping("accountInfo2")
	public ResponseEntity<Account> accountInfo2(@RequestParam("id") String id) {
		ResponseEntity<String> res = null;
		
		try {
			Account acc = accountDAO.selectAccount(id);
			if(acc != null) {
				return new ResponseEntity<Account>(acc, HttpStatus.OK);
			} else throw new Exception("계좌번호 오류");
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Account>(new Account("noid", "noname", 0, null, null), HttpStatus.ACCEPTED);
		}
	}
}
