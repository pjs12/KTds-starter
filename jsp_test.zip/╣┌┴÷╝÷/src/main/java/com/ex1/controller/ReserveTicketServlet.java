package com.ex1.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/reserveTicket")
public class ReserveTicketServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		Calendar c = Calendar.getInstance();
		int nowyear = c.get(Calendar.YEAR);
		
		String birthday = request.getParameter("birthday");
		int type = Integer.parseInt(request.getParameter("type"));
		int age = nowyear - Integer.parseInt(request.getParameter("birthday").split("/")[0]);
		String grade = "";
		if(age >= 0 && age < 19) {
			grade = "미성년자";
		} else if(age >= 19 && age < 60) {
			grade = "성인";
		} else if (age >= 60) {
			grade = "경로우대자";
		}
		
		request.setAttribute("birthday", birthday);
		request.setAttribute("type", type);
		request.setAttribute("age", age);
		request.setAttribute("grade", grade);
		
		response.setCharacterEncoding("utf-8");
		request.getRequestDispatcher("ex1/reservationInfo.jsp").forward(request, response);
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("ex1/ticket.jsp").forward(request, response);
	}

}
